﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Globalization;
using System.Reflection;
using System.Windows.Forms;
using System.Drawing;

namespace PMEngine
{
    /// <summary>
    /// Содержит различные вспомогательные операции 
    /// </summary>
    public class Utility
    {
        /// <summary>
        /// Разделитель строк CSV для процедур парсинга
        /// </summary>
        internal static Char[] CsvDelimiter = { ';' };

        /// <summary>
        /// NT-Удалить из строки текста CSV-разделители
        /// </summary>
        /// <param name="p"></param>
        /// <returns></returns>
        public static string StringRemoveCsvChars(string p)
        {
            String result = p.Replace(";", ".,");

            return result;
        }
        /// <summary>
        /// NT-Return date string as 23.01.2018 23:14:59
        /// </summary>
        /// <param name="time"></param>
        /// <returns></returns>
        public static string StringFromDateTime(DateTime time)
        {
            return time.ToString(CultureInfo.GetCultureInfo("ru-RU"));//23.01.2018 23:14:59
        }

        internal static DateTime DateTimeFromString(string p)
        {
            return DateTime.Parse(p, CultureInfo.GetCultureInfo("ru-RU"));
        }

        /// <summary>
        /// NR-Конвертировать локальный путь в сетевой путь
        /// </summary>
        /// <param name="localPath">Локальный файловый путь к документу</param>
        /// <returns>Возвращает сетевой путь к документу</returns>
        public static string LocalPathToUNCpath(string localPath)
        {
            //TODO: использовать готовую функцию из моей библиотеки классов
            //а тут просто обертка к ней будет
            //А ее там и нет - она в Инвентарь была реализована, а в библиотеку классов я ее не внес.
            //Наверно, думал, что нигде более не потребуется.
            //Надо и тут ее реализовать и в библиотеку добавить после тестирования.
            
            throw new NotImplementedException();
        }
        /// <summary>
        /// NR-Конвертировать сетевой путь в локальный путь
        /// </summary>
        /// <param name="UNCpath">сетевой путь к документу</param>
        /// <returns>Возвращает локальный файловый путь к документу</returns>
        public static string UNCpathToLocalPath(string UNCpath)
        {
            //TODO: использовать готовую функцию из моей библиотеки классов
            //а тут просто обертка к ней будет
            throw new NotImplementedException();
        }

        /// <summary>
        /// NT-Получить текущую версию движка (сборки).
        /// </summary>
        /// <returns></returns>
        public static Version getCurrentEngineVersion()
        {
            return Assembly.GetExecutingAssembly().GetName().Version;
        }
        /// <summary>
        /// NT-Сравнить версию движка из ФайлОписанияПроекта и текущую версию движка
        /// </summary>
        /// <param name="version"></param>
        /// <returns></returns>
        public static bool isCompatibleVersion(Version version)
        {
            Version cur = getCurrentEngineVersion();
            //compare by 1 and 2 members
            return ((cur.Major == version.Major) && (cur.Minor == version.Minor));
        }

        /// <summary>
        /// NT-Возвращает флаг что указанный каталог не может обновляться.
        /// </summary>
        /// <returns>Returns True if folder is ReadOnly, False otherwise</returns>
        private static bool isFolderReadOnly(String folderPath)
        {
            bool ro = false;
            //generate test file name
            String test = Path.Combine(folderPath, "writetest.txt");

            try
            {
                //if test file already exists, try remove it
                if (File.Exists(test))
                    File.Delete(test);//тут тоже будет исключение, если каталог read-only
                //test creation 
                FileStream fs = File.Create(test);
                fs.Close();
            }
            catch (Exception)
            {
                ro = true;
            }
            finally
            {
                File.Delete(test);
            }
            return ro;
        }

        #region Forms functions
        /// <summary>
        /// Цвет для выделения неправильного веб-имени  фоном текстового поля
        /// </summary>
        internal static Color InvalidWebNameBackColor = Color.MistyRose;

        /// <summary>
        /// NT-Установить цвет ошибки для текстбокса и вывести сообщение в строке состояния, если она есть
        /// </summary>
        /// <param name="wrong">Флаг ошибки</param>
        /// <param name="control">Текстбокс</param>
        /// <param name="statusBarLabel">Объект текста на статусбаре или null</param>
        /// <param name="statusMsg">Сообщение об ошибке, для статусбара</param>
        public static void colorizeWrongTextBox(bool wrong, TextBox control, ToolStripStatusLabel statusBarLabel, String statusMsg)
        {
            Color backColor;
            //set error color for textbox
            if (wrong)
            {
                backColor = InvalidWebNameBackColor;

            }
            else
            {
                backColor = Color.White;
            }
            control.BackColor = backColor;

            //set new status bar message text
            String msg;
            if (statusBarLabel != null)
            {
                if (wrong)
                    msg = statusMsg;
                else
                    msg = String.Empty;
                //set new text
                statusBarLabel.Text = msg;
            }

            return;
        }
        #endregion

    }
}
