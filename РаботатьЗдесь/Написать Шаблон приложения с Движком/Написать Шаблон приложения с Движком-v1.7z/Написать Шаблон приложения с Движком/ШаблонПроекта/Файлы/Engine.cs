﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using PMEngine.Nado;

namespace PMEngine
{
    /// <summary>
    /// NR-Представляет собственно движок.
    /// Должен запускаться только в одном экземпляре?
    /// </summary>
    public class Engine
    {
        #region *** Поля и константы движка ***
        /// <summary>
        /// Адаптер БД для хранения элементов
        /// </summary>
        private DbAdapter m_dbAdapter;
        /// <summary>
        /// Флаг, что движок работает в режиме Только чтение.
        /// </summary>
        private bool m_ReadOnly;
        #endregion

        /// <summary>
        /// Default constructor
        /// </summary>
        public Engine()
        {


        }
        #region *** Проперти движка ***
        /// <summary>
        /// Адаптер БД для хранения элементов
        /// </summary>
        public DbAdapter DbAdapter
        {
            get { return m_dbAdapter; }
            set { m_dbAdapter = value; }
        }

        /// <summary>
        /// NT-Получить текущую версию движка
        /// </summary>
        public Version EngineVersion
        {
            get { return Utility.getCurrentEngineVersion(); }
        }
        #endregion


        #region *** Главные функции движка ***
        /// <summary>
        /// NR-Создать новый проект
        /// </summary>
        public void Create(EngineSettings si)
        {
            //Функция создания проекта. 
            //Тут пользователь должен заполнить свойства проекта и движок создаст проект.
            //Так как там много специфических свойств, которые знает только пользователь.
            //Мне же для темы шаблона нужен только путь к каталогу проекта.
            //Важно, что нужно указать путь к Каталогу проекта (а не к родительской категории), но эта папка не должна уже существовать.
            
            throw new System.NotImplementedException();

            //этот код для примера только
            ////1) создать каталог хранилища
            ////создать корневой каталог хранилища
            //if (Directory.Exists(si.StoragePath))
            //    throw new Exception("Storage already exists!");
            //DirectoryInfo di = new DirectoryInfo(si.StoragePath);
            //di.Create();
            ////установить атрибуты, запрещающие индексацию, архивацию и прочее в том же духе
            //di.Attributes = (di.Attributes | FileAttributes.NotContentIndexed);
            //di = null;
            ////создать файл описания хранилища
            //StorageInfo.StoreInfo(si);
            ////создать подкаталоги хранилища docs pics
            //String pics = Path.Combine(si.StoragePath, ArchiveController.ImagesDir);
            //Directory.CreateDirectory(pics);
            //String docs = Path.Combine(si.StoragePath, ArchiveController.DocumentsDir);
            //Directory.CreateDirectory(docs);
            ////извлечь из ресурсов сборки в корневой каталог шаблон БД хранилища
            //String db = Path.Combine(si.StoragePath, DbAdapter.DatabaseFileName);
            //extractDbFile(db);
            ////2) открыть менеджер хранилища
            //Manager man = new Manager();
            //man.openIfNewOnly(si);//записать данные о хранилище в БД, кроме пути к хранилищу
            //man.Close();
            ////вернуть открытый менеджер хранилища
            //man.Open(si.StoragePath);
            //return man;
        }

        /// <summary>
        /// NR-Открыть проект
        /// </summary>
        /// <param name="storagePath">Путь к каталогу данных проекта</param>
        /// <param name="readOnly">Открыть только для чтения</param>
        public void Open(String storagePath, bool readOnly)
        {
            ////init adapter and open database
            //this.m_dbAdapter = PMEngine.DbAdapter.SetupDbAdapter(storagePath, readOnly);

            ////или :

            ////check disk writable
            //this.m_ReadOnly = isReadOnly(storagePath);
            //...
            ////init database
            //string db = Path.Combine(storagePath, DbAdapter.DatabaseFileName);
            //this.m_db = DbAdapter.SetupDbAdapter(this, db, this.m_ReadOnly);
            //...
            ////TODO: добавить код открытия движка 

            return;
        }

        /// <summary>
        /// NR-Открыть проект один раз при его создании, 
        /// когда БД еще не содержит всех нужных данных, а ее уже надо открыть.  
        /// </summary>
        /// <param name="si"></param>
        private void openIfNewOnly(EngineSettings si)
        {
            throw new System.NotImplementedException();//TODO: add code here
        }

        /// <summary>
        /// NR-Завершить сеанс работы
        /// </summary>
        public void Close()
        {

            //close database adapter
            this.m_dbAdapter.Disconnect();
            this.m_dbAdapter = null;

            //TODO: добавить код закрытия движка 
            throw new System.NotImplementedException();
        }

        /// <summary>
        /// NR-Оптимизация проекта - незакончено, неясно как сделать и как использовать потом
        /// </summary>
        public void Optimize()
        {
            CheckReadOnly();
            //TODO: добавить код оптимизаци Хранилища здесь
            throw new System.NotImplementedException();
        }

        
        //Функция очистки. Ни разу не пользовался, проще создать новый проект. Но для комплекта тут реализована.
        ///// <summary>
        ///// NFT-Очистить проект
        ///// </summary>
        ///// <returns>Return True if success, False otherwise</returns>
        //public bool ClearStorage()
        //{
        //    CheckReadOnly();
        //    //Тут очищаем все таблицы БД кроме таблицы свойств, удаляем все архивы, пересчитываем статистику и вносим ее в БД.
        //    //в результате должно получиься пустое Хранилище, сохранившее свойства - имя, квалифицированное имя, путь итп.
        //    if (m_db.ClearDb() == true)
        //    {
        //        m_docController.Clear();
        //        m_picController.Clear();
        //        this.updateStorageInfo();//это будет выполнено также при закрытии менеджера.
        //        return true;
        //    }
        //    else return false;
        //}

        /// <summary>
        /// NR-Проверить, что указанный каталог является каталогом Хранилища
        /// </summary>
        /// <param name="path">Путь к каталогу</param>
        /// <returns>Возвращает true, если каталог является каталогом Хранилища. В противном случае возвращает false</returns>
        public static bool IsStorageFolder(string path)
        {
            //Этот код только для примера, его нужно переписать
            
            //критерии:
            //папка должна содержать файл "description.xml"
            //папка должна содержать файл db.mdb
            //папка должна содержать папки docs pics
            //файл "description.xml" должен читаться без проблем

            //String p = Path.Combine(path, ArchiveController.DocumentsDir);
            //if (!Directory.Exists(p)) return false;
            //p = Path.Combine(path, ArchiveController.ImagesDir);
            //if (!Directory.Exists(p)) return false;
            //p = Path.Combine(path, DbAdapter.DatabaseFileName);
            //if (!File.Exists(p)) return false;
            //p = Path.Combine(path, Manager.DescriptionFileName);
            //if (!File.Exists(p)) return false;
            ////try load descr file
            //bool result = true;
            //try
            //{
            //    StorageInfo si = StorageInfo.GetInfo(path);
            //}
            //catch (Exception)
            //{
            //    result = false;
            //}
            //return result;

            throw new System.NotImplementedException();//TODO: add code here
        }

        /// <summary>
        /// NR-Удалить Хранилище
        /// </summary>
        /// <param name="storagePath">Путь к каталогу Хранилища</param>
        /// <returns>Возвращает true, если Хранилище успешно удалено или его каталог не существует.
        /// Возвращает false, если удалить Хранилище не удалось по какой-либо причине.</returns>
        public static bool DeleteStorage(String storagePath)
        {
            //Этот код только для примера, его нужно переписать
            throw new System.NotImplementedException();//TODO: add code here
            
            ////если каталог не существует, возвращаем  true
            //if (!Directory.Exists(storagePath)) return true;
            ////1) если Хранилище на диске только для чтения, то вернуть false.
            //if (isReadOnly(storagePath)) return false;
            ////2) пробуем переименовать каталог Хранилища
            ////если получится, то каталог никем не используется. удалим каталог и вернем true.
            ////иначе будет выброшено исключение - перехватим его и вернем false
            ////сначала еще надо сгенерировать такое новое имя каталога, чтобы незанятое было.
            //String newName = String.Empty;
            //String preRoot = Path.GetDirectoryName(storagePath);
            //for (int i = 0; i < 16384; i++)
            //{
            //    newName = Path.Combine(preRoot, "tmp" + i.ToString());
            //    if (!Directory.Exists(newName)) break;
            //}
            ////тут мы должны оказаться с уникальным именем
            //if (Directory.Exists(newName))
            //    throw new Exception("Error! Cannot create temp directory name!");
            ////пробуем переименовать каталог
            //try
            //{
            //    Directory.Move(storagePath, newName);
            //}
            //catch (Exception)
            //{
            //    return false;
            //}
            ////каталог не используется, удалим его
            ////TODO: вот лучше бы его через шелл и в корзину удалить. Хотя... Удалять же будет не приложение. Некому показывать шелл.
            ////Надо это решить как удобнее будет. Может, через аргументы передавать способ - с гуем в корзину или нет.
            //Directory.Delete(newName, true);
            ////если тут возникнут проблемы, то хранилище все равно уже будет повреждено.
            ////так что выброшенное исключение достанется вызывающему коду.
            //return true;
        }

        //Еще есть функция получения информации о проекте, но я не знаю, пригодится ли тут она. 
        //Она просто возвращает содержимое файла настроек, который содержит также и статистику проекта.
        //Поэтому я не стал ее тут приводить.

        /// <summary>
        /// NR-зарегистрировать единственный экземпляр. Если это не так, вернуть False.
        /// </summary>
        /// <param name="uid">Уникальный строковый идентификатор приложения</param>
        public bool RegisterSingleInstance(string uid)
        {
            throw new System.NotImplementedException();//TODO: add code here
        }

        /// <summary>
        /// NR-Получить текстовое представление движка для отладки
        /// </summary>
        /// <returns></returns>
        public override String ToString()
        {
            return base.ToString();//TODO: add code here
        }

#endregion


        #region *** BotAPI functions ***
        //TODO: добавить тут рабочие функции движка 
        #endregion

        #region *** Вспомогательные функции движка ***
        //Тут размещать внутренние функции движка



        /// <summary>
        /// NT-Получить строку текущей версии сборки движка
        /// </summary>
        /// <returns></returns>
        public static string getEngineVersionString()
        {
            //DONE: Убедиться что это возвращает версию текущей сборки а не приложения.
            return Assembly.GetExecutingAssembly().GetName().Version.ToString();
        }

        //Эта функция уже есть в адаптере БД, а здесь она зачем?
        /// <summary>
        /// NT-Извлечь файл шаблона базы данных из ресурсов сборки
        /// </summary>
        /// <param name="filepath">Путь к итоговому файлу</param>
        private static void extractDbFile(string filepath)
        {
            
            FileStream fs = new FileStream(filepath, FileMode.Create);
            byte[] content = Properties.Resources._base;//database template name
            fs.Write(content, 0, content.Length);
            fs.Close();
        }
        /// <summary>
        /// NT-Проверить режим read-only и выбросить исключение
        /// </summary>
        private void CheckReadOnly()
        {
            if (this.m_ReadOnly == true)
                throw new Exception("Error: Writing to read-only storage!");
        }

        #endregion





    }
}
