﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PMEngine
{
    /// <summary>
    /// NR-Это класс, управляющий Каталогом данных проекта. 
    /// </summary>
    public class ProjectFolderManager
    {
        
        #region Константы



        #endregion

        #region Поля

        /// <summary>
        /// Путь к каталогу коллекции проектов.
        /// </summary>
        private string m_mainFolderPath;

        #endregion

        /// <summary>
        /// NR-Конструктор
        /// </summary>
        public ProjectFolderManager()
        {
            throw new NotImplementedException();//TODO: Add code here...
        }

        #region Проперти

        /// <summary>
        /// Главный каталог коллекции проектов
        /// </summary>
        public string ПутьГлавныйКаталог
        {
            get
            {
                return this.m_mainFolderPath;
            }
            set
            {
                this.m_mainFolderPath = value;
            }
        }

        #endregion

        /// <summary>
        /// NR-Возвращает True если каталог это коллекция каталогов проектов
        /// </summary>
        /// <param name="directoryPath">Путь к каталогу</param>
        /// <returns></returns>
        public static bool isFolderForThis(String directoryPath)
        {
            throw new NotImplementedException();//TODO: Add code here...
        }

        /// <summary>
        /// NR-Создать каталог Коллекции проектов
        /// </summary>
        /// <param name="parentDirPath">Путь к родительскому каталогу</param>
        public void Create(String parentDirPath)
        {
            throw new NotImplementedException();//TODO: Add code here...
        }

        /// <summary>
        /// NR-Получить текстовое представление объекта
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return base.ToString();//TODO: Add code here...
        }

    }
}
